# Next.js vs Next.js + Gaine

**No clear winner on the key metrics**

Profile `mobile` · 10 runs × 2 page(s) · 2026-11-27T23:07:14.406Z  
Gaine wins 4 · Plain wins 8 · ties 10

### Load (browser)

| Metric | Plain | Gaine | Δ | Winner |
|---|---:|---:|---:|---|
| TTFB | 151 ms | 152 ms | +0.0% | ≈ tie |
| First Contentful Paint | 468 ms | 296 ms | -36.8% | ▲ Gaine |
| Largest Contentful Paint | 1,968 ms | 296 ms | -85.0% | ▲ Gaine |
| Total Blocking Time | 67 ms | 64 ms | -4.5% | ≈ tie |
| Cumulative Layout Shift | 0.000 | 0.000 | 0.0% | ≈ tie |
| DOMContentLoaded | 467 ms | 304 ms | -35.0% | ▲ Gaine |
| Load event | 1,325 ms | 1,370 ms | +3.4% | ▼ Plain |

### Payload (per page)

| Metric | Plain | Gaine | Δ | Winner |
|---|---:|---:|---:|---|
| Requests | 8 | 10 | +25.0% | ▼ Plain |
| HTML (transfer) | 3.8 kB | 11.9 kB | +213.6% | ▼ Plain |
| JavaScript (transfer) | 139.0 kB | 173.7 kB | +25.0% | ▼ Plain |
| CSS (transfer) | 2.7 kB | 0 B | -100.0% | ▲ Gaine |
| Fonts (transfer) | 0 B | 0 B | 0.0% | ≈ tie |
| Images (transfer) | 0 B | 0 B | 0.0% | ≈ tie |
| Total (transfer) | 145.4 kB | 196.1 kB | +34.9% | ▼ Plain |

### Server (next start)

| Metric | Plain | Gaine | Δ | Winner |
|---|---:|---:|---:|---|
| Throughput | 1,327 req/s | 903 req/s | -32.0% | ≈ tie |
| Latency p50 | 11.41 ms | 16.9 ms | +48.2% | ≈ tie |
| Latency p95 | 19.19 ms | 26.6 ms | +38.6% | ≈ tie |

### Build

| Metric | Plain | Gaine | Δ | Winner |
|---|---:|---:|---:|---|
| next build time | 14.75 s | 8.61 s | -41.6% | ≈ tie |
| .next size (no cache) | 7.39 MB | 10.25 MB | +38.7% | ▼ Plain |
| Static JS (gzip, all chunks) | 175.7 kB | 210.4 kB | +19.8% | ▼ Plain |
| Static CSS (gzip) | 2.3 kB | 4.5 kB | +95.3% | ▼ Plain |
| JS chunks | 10 | 10 | 0.0% | ≈ tie |

_Medians. Lab metrics are significant at p<0.05 (Mann-Whitney) and ≥3% change; byte/count metrics are deterministic._