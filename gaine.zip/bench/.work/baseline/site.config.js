export const siteName = "bench-baseline";
export const baseUrl = process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000";
