# gaine

Scaffold a Gaine project with zero runtime dependencies (the interactive menu uses Node's built-in `readline`).

Docs: [https://gaine.soteenstudio.my.id](https://gaine.soteenstudio.my.id)

```bash
npx gaine@latest
```

It'll ask for:

1. Project name (use `.` for here)
2. Framework (**Next.js** or **VitePress**)
3. Language (**TypeScript** or **JavaScript**)

Skip the menu with flags:

```bash
npx gaine@latest my-app --framework next --lang ts

# or
npx gaine@latest my-docs -f vitepress -l js
```

## Templates

| Template | Included |
| --- | --- |
| `next-ts`, `next-js` | Next 16 App Router, `@gaine/core` + `@gaine/nextjs`, i18n (`id`/`en`), `proxy.ts`, robots, sitemap, example page |
| `vitepress-ts`, `vitepress-js` | VitePress 1.x, `@gaine/core` + `@gaine/vitepress`, i18n (`id`/`en`), navbar language switcher + theme toggle, build-time robots and sitemap |